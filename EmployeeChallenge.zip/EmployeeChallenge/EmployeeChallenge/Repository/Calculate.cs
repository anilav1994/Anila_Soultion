﻿using EmployeeChallenge.Model;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Mvc;

namespace EmployeeChallenge.Repository
{
    public class Calculate
    {
        EmployeeRepository employeeRepository;
        AbsenceRepository absenceRepository;
        public Calculate()
        {
            employeeRepository = new EmployeeRepository();
            absenceRepository = new AbsenceRepository();
        }
        public string CalculateAbsence()
        {
            List<Employee> employeeRecord = employeeRepository.GetEmployees();
            List<Absence> absencesRecord = absenceRepository.GetAbsence();

            //string result = CombineTables(employeeRecord, absencesRecord);
            var testResult = GetEmployeeAbsenceCount(employeeRecord, absencesRecord);
            return testResult;
        }

        public string CombineTables(List<Employee> employeeRecord, List<Absence> absencesRecord)
        {
            //List<object> newList = new List<object>();
            //foreach(var item in employeeRecord)
            //{               
            //var result = employeeRecord.Where(e => absencesRecord.Any(a => e.Id == a.EmployeeId));
            //var result = absencesRecord.Where(e => e.EmployeeId == employeeRecord.Select(x=>x.Id));

            //var test = item.Select(e => absencesRecord.Where(a => a.EmployeeId == item.Id));

            //    newList.Add(result);                
            //}

            var result = from e in employeeRecord
                         join a in absencesRecord
                         on e.Id equals a.EmployeeId
                         select new { e, a };

            string Json = JsonConvert.SerializeObject(result);
            return Json;
        }
        public string GetEmployeeAbsenceCount(List<Employee> employeeRecord, List<Absence> absencesRecord)
        {
            var result =  from e in employeeRecord
                          join a in absencesRecord on e.Id equals a.EmployeeId into g
                          select new { e, Count = g.Count() };

            var json = JsonConvert.SerializeObject(result);
            return json;           
        }

        public string GetAbsence(int empId)
        {
            List<Absence> absencesRecord = absenceRepository.GetAbsence();

            var result = from a in absencesRecord
                         where a.EmployeeId == empId
                         select new { a };

            //var absenceTest = absencesRecord.Where(a => a.EmployeeId == empId).Select();
            var json = JsonConvert.SerializeObject(result);
            return json;
        }
    }
}
