﻿using CsvHelper;
using EmployeeChallenge.Model;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeChallenge.Repository
{
    public class AbsenceRepository : IAbsence
    {
        public List<Absence> GetAbsence()
        {
            List<Absence> absenceRecords = new List<Absence>();

            using (var streamReader = new StreamReader(@"C:\Users\anila\Desktop\New folder\EmployeeChallenge\EmployeeChallenge\CSVFiles\absences.csv"))
            {
                using (var csvReader = new CsvReader(streamReader, CultureInfo.InvariantCulture))
                {
                    absenceRecords = csvReader.GetRecords<Absence>().ToList();
                }
            }

            return absenceRecords;
        }
    }
}
