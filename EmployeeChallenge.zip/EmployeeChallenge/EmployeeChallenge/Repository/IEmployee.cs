﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmployeeChallenge.Model;

namespace EmployeeChallenge.Repository
{
    public interface IEmployee
    {        public List<Employee> GetEmployees();
    }
}
