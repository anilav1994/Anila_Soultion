﻿using EmployeeChallenge.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeChallenge.Repository
{
    public interface IAbsence
    {
        public List<Absence> GetAbsence();
    }
}
