﻿using CsvHelper;
using EmployeeChallenge.Model;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeChallenge.Repository
{
    public class EmployeeRepository : IEmployee
    {
        public List<Employee> GetEmployees()
        {
            List<Employee> employeeRecords = new List<Employee>();
            
            using (var streamReader = new StreamReader(@"C:\Users\anila\Desktop\New folder\EmployeeChallenge\EmployeeChallenge\CSVFiles\employees.csv"))
            {
                using (var csvReader = new CsvReader(streamReader, CultureInfo.InvariantCulture))
                {
                    employeeRecords = csvReader.GetRecords<Employee>().ToList();
                }
            }

            return employeeRecords;
        }
    }
}
