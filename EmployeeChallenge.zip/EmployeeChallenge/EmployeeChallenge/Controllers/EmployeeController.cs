﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmployeeChallenge.Repository;

namespace EmployeeChallenge.Controllers
{
    [Route("[controller]")]
    public class EmployeeController : Controller
    {
        [HttpGet]
        public IActionResult Get()
        {
            Calculate calculate = new Calculate();
            var result = calculate.CalculateAbsence();
            return Ok(result);
        }
        [HttpGet("getabsence")]
        public IActionResult GetAbsence(int employeeId)
        {
            Calculate calculate = new Calculate();
            object result = calculate.GetAbsence(employeeId);
            return Json(result);
        }
    }
}
