﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeWebApp.Models
{
    public class Absence
    {
        public int Id { get; set; }
        public string Start { get; set; }
        public string End { get; set; }
        public int Type { get; set; }
        public int EmployeeId { get; set; }
    }

    public class AbsenceRoot
    {
        public Absence A { get; set; }
    }
}
