﻿using EmployeeWebApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Diagnostics;
using System.Net.Http;
using System.Threading.Tasks;
using EmployeeWebApp.Helper;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Collections.Generic;
using System.Net.Http.Json;
using System.Linq;

namespace EmployeeWebApp.Controllers
{
    public class HomeController : Controller
    {
       
        EmployeeHelper _helper = new EmployeeHelper();
       
        public async Task<IActionResult> Index()
        {
            List<Root> rootList = new List<Root>();
            HttpClient client = _helper.Initial();           
            HttpResponseMessage res = await client.GetAsync("employee");
            if (res.IsSuccessStatusCode)
            {
                var result = await res.Content.ReadAsStringAsync();
                //var json = string.Format("[{0}]", result);
                var e = JsonConvert.DeserializeObject(result).ToString();
                rootList = JsonConvert.DeserializeObject<List<Root>>(e);
                //var e = JsonConvert.DeserializeObject(result);
            }
            return View(rootList);
        }


        public async Task<IActionResult> GetAbsence(int id)
        {
            List<AbsenceRoot> absenceList = new List<AbsenceRoot>();
            HttpClient client = _helper.Initial();
            HttpResponseMessage res = await client.GetAsync("employee/getabsence?employeeId="+id);
            if (res.IsSuccessStatusCode)
            {
                var result = await res.Content.ReadAsStringAsync();                
                var a = JsonConvert.DeserializeObject(result).ToString();
                absenceList = JsonConvert.DeserializeObject<List<AbsenceRoot>>(a);
            }
           
            //var absence = absenceList.Select(e => absenceList.Where(a => a.EmployeeId == id)).ToList();
            return View(absenceList);
        }


    }
}
